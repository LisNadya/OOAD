 
import java.awt.Point;
import java.util.ArrayList;

/**
 * This class for the character Sun in the Myrmidon Chess which can be moved
 * up to two steps in any directions
 *
 * @author (Muhamad Hafiz Bin Ghani)
 * @version (9/1/2018)
 */
public class Sun extends ChessPiece
{
	//iName - name of Sun is always sun
	private static final String iName = "Sun";
		
    /**
     * Constructor set the initial position of the chess piece
     */
    public Sun(Point aFinalPoint, String aColor)
    {
        super(aFinalPoint, aColor);
    }


    /**
     * This method validate the move of the chess piece 
     * @param aFinalPoint - the desired point of the chess piece
     */
    public boolean validateMove(Point aFinalPoint){

        if(Math.abs(super.getCurrentPosition().x - aFinalPoint.x) > 100 || Math.abs(super.getCurrentPosition().y - aFinalPoint.y) > 100 ){
          return false;
        }else if( super.getCurrentPosition().x - aFinalPoint.x == 0 && super.getCurrentPosition().y - aFinalPoint.y == 0){   
        	return false;
        }else{
          return true;
        }
    }
    

    /**
     *  This method transform the Sun to become the
     * @return 
     */
    public ChessPiece transform(ArrayList<ChessPiece> aChessPiece){
    	return null;
    }


	@Override
	public String getName() {
		return iName;
	}


	@Override
	public ArrayList<Point> getPossibleTiles(Point aFinalPoint) {
		ArrayList<Point> iCoordinates = new ArrayList<Point>();
    	
		if(validateMove(aFinalPoint))	
    	iCoordinates.add(aFinalPoint);
    	
    	return iCoordinates;
	}

}
