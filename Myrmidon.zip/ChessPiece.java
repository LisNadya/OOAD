 
import java.awt.Point;
import java.io.Serializable;
import java.util.ArrayList;

/**
 * Abstract class for chess pieces
 */
public abstract class ChessPiece implements Serializable
{


    //iFinalPoint - piece final point
    private Point iFinalPoint;
    //iColor - piece color
    private String iColor;
 

    /**
     * ChessPiece - ChessPiece constructor
     * @param aFinalPoint - arguement for final point
     * @param aColor - arguement for color
     */
    public ChessPiece(Point aFinalPoint, String aColor)
    {
        iFinalPoint=aFinalPoint;
        setColor(aColor);
    }

    /**
     * validateMove - Function that determines if pathway is valid
     * @param aInitialPoint - arguement for initial point
     * @param aFinalPoint - arguement for final point
     */
    public abstract boolean validateMove(Point aFinalPoint);

    /**
     * transform - Function that indicates next transformation of Piece
     * @return 
     */
    public abstract ChessPiece transform(ArrayList<ChessPiece> aChesspiece);
    
    public abstract String getName();
    
    public abstract ArrayList<Point> getPossibleTiles(Point aFinalPoint);

    /**
     * This method is to get the current position of the chess piece
     * @return iFinalPoint - the latest position of the chess piece
     */
    public Point getCurrentPosition(){
        return iFinalPoint;
    }

    /**
     * This method is to set the current possition after the chess piece move to the desired Point
     * @param aFinalPoint the desired point of the chess piece moved
     */
    public void  setCurrentPosition(Point aFinalPoint){
      iFinalPoint = aFinalPoint;
    }

	/**
	 * @return the iColor
	 */
	public String getColor() {
		return iColor;
	}

	/**
	 * @param iColor the iColor to set
	 */
	public void setColor(String iColor) {
		this.iColor = iColor;
	}
    

}
