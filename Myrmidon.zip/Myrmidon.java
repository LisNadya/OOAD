
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Stack;

/*
 * Myrmidon is the GUI for the game
 *
 * @author Muhamad Hafiz Bin Ghani
 * @author Lis Nadya
 * @author Aishah
 * @author Lim
 *
 */
public class Myrmidon implements Serializable{

    /*#############################################################################
     * VARIABLES BUTTONS
     * ############################################################################
     */
    //button for tiles
    private JButton[] iTile = new JButton[42];
    //menu buttons
    private JButton[] iMenu = new JButton [4];
    //button for red pieces
    private JButton[] iRedButton;
    //button for blue pieces
    private JButton[] iBlueButton;
    //Desired piece button to be moved
    private JButton iPiece;
    //Enemy to be killed button
    private JButton iEnemyPiece;


    /*#############################################################################
     * VARIABLES WARNING MESSAGE, MENU, COLOR,
     * ############################################################################
     */
    //menu names
    private final String[] menuName = {"New Game", "Save Game", "Load Game", "Quit"};
    //blue color
    private final String blue = "b";
    //red color
    private final String red = "r";
    //file saving game
    private final String[] filenames = {"Myrmidonrp.txt","Myrmidonbp.txt","Myrmidontiles.txt",
                                        "Myrmidoncount.txt", "Myrmidonturn.txt"};
    //random warning message
    private final String[] warning = {"NOT YOUR TURN YET!",
                                "DON'T CHEAT! GOD SEE YOU!",
                                "PATIENCE PLEASE! WAIT YOUR TURN!",
                                "GIVING YOU EXTRA TIME TO THINK! LET YOUR OPPONENT MOVE!",
                                "WAIT FOR YOUR TURN DUDE!",
                                "CAN'T TRUST YOU ANYMORE! WAIT TILL YOUR TURN PLEASE!",
                                "SAY NO TO CORRUPTION! WAIT YOUR TURN!",
                                "I AM TRUSTING YOU WITH ALL OF MY HEART! PLEASE DONT SPOIL IT! :(",
                                "IT'S NOT GONNA WORK! WAIT YOUR TURN! :P",
                                "WRONG TIME TO CHEAT! WAIT YOUR TURN! :P"};
    //instruction for the game
    private final String instruction = "MYRMIDON GAME RULES:\n" +
                                      "1. The Plus can move vertically or horizontally, up to 2 steps in any direction in a straight line.\n" +
                                      "2. The Triangle can move diagonally, both up and down, up to 2 steps in any direction in a straight line.\n" +
                                      "3. The Chevron must move in an L shape, exactly two steps then 1 step right or left. (This is the only" +
                                      " piece that can jump over other pieces)\n"+
                                      "4. The Sun can move only 1 step in any direction. The game ends when the sun is captured by the" +
                                      " other side.\n";


    /*#############################################################################
     * VARIABLES FOR UI
     * ############################################################################
     */
    //Chess board
    private ChessBoardFacade iChessBoardFacade = new ChessBoardFacade();
    //ChessBoard panel
    private JLayeredPane iBoard = new JLayeredPane();
    //Frame for the whole game
    private JFrame iFrame;
    //To determine whose turn
    private JLabel iNotification;


    /*#############################################################################
     * VARIABLES FOR GAME
     * ############################################################################
     */

    //iGameStart is to indicate if game has started or not
    private boolean iGameStart = false;
    //iNumTurn is number of turns
    private int iCounter = 0;
    //Chess tiles information
    private ChessTile iChessTiles;
    //Red chess pieces information
    private ArrayList<ChessPiece> iRedPiece;
    //Blue chess pieces information
    private ArrayList<ChessPiece> iBluePiece;
    //iStartTime is current program time
    private long iStartTime;
    //iTimer is for program timer
    private Timer iTimer;
    // Dynamic coordinate of the piece
    private Point iInitialPoint, iFinalPoint;
    // Fixed coordinate of the piece
    private Point iFinalPointValidation, iInitialPointValidation;
    // real time distance for X
    private double iDistanceSoFarX = 0 ;
    // real time distance  for Y
    private double iDistanceSoFarY = 0 ;
    //Keep the red pieces and blue pieces together
    private HashMap<String,ArrayList<ChessPiece>> iPieces = new HashMap<String,ArrayList<ChessPiece>>();
    //Validate the movement of the piece
    private boolean iPieceValidation = false;
    //to check is either the game is already ended
    private boolean iEndGame = false;
    //to check the turn for player
    private boolean iBlueTurn = true;
    //to check the turn for player
    private boolean iRedTurn = false;
    // to enable and disable the button
    private boolean iEnable = true;




    /**
    * constructor for Myrmidon
    * initializing the game
    *
    * @throws IOException
    * @throws UnsupportedAudioFileException
    */
    public Myrmidon() throws UnsupportedAudioFileException, IOException{
    
        /*#####################################################################
         * UI INITIALIZATION
         *#####################################################################
         */
    
        //lFrame is frame for the whole game
        iFrame = new JFrame("Myrmidon");
        iFrame.setLayout(new BorderLayout());
    
    
        //Put the turn's notification
        JPanel lNotificationPanel = new JPanel();
        lNotificationPanel.setPreferredSize(new Dimension(350,60));
        lNotificationPanel.setBackground(Color.BLACK);
    
        //Blue is going to take the first turn at the very beginning of the game
        if(iGameStart==false){
            iNotification=new JLabel("<html>New Game<br/>Blue's turn</html>", SwingConstants.CENTER);
        }
    
        iNotification.setFont(new Font("Cooper Black", Font.PLAIN, 18));
        iNotification.setForeground(Color.WHITE);
        lNotificationPanel.add(iNotification);
    
    
        //panel is holding the chessboard
        JPanel lChessBoardPanel = new JPanel(new BorderLayout());
        Dimension lExpectedDimension = new Dimension(700, 600);
        iBoard.setSize(600, 700);
    
        //adds tiles into panel  and set the chess tiles setting
        iChessTiles = new ChessTile();
        iChessTiles.setChessTiles(iChessBoardFacade.setChessTiles(iTile, iBoard,new TileListener()));
    
        //panel.add(lBoard);
        lChessBoardPanel.setPreferredSize(lExpectedDimension);
        lChessBoardPanel.setMaximumSize(lExpectedDimension);
        lChessBoardPanel.setMinimumSize(lExpectedDimension);
        lChessBoardPanel.add(iBoard, BorderLayout.CENTER);
    
        Box lBoxChessBoard = new Box(BoxLayout.Y_AXIS);
    
        lBoxChessBoard.add(Box.createVerticalGlue());
        lBoxChessBoard.add(lChessBoardPanel);
        lBoxChessBoard.add(Box.createVerticalGlue());
        //Adding the chess board to the main frame
        iFrame.add(lBoxChessBoard, BorderLayout.CENTER);
        //Adding menu to the JFrame
        iFrame.add(iChessBoardFacade.setMenu(menuName, iMenu, new MenuButtonListener(), lNotificationPanel),BorderLayout.WEST);
        //lFrame characteristics
        iFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        iFrame.setSize(1100, 660);
        iFrame.setResizable(true);
        iFrame.getContentPane().setBackground(new Color(35,35,35));
        iFrame.setVisible(true);
    
        //show the instruction before starting the game
        JOptionPane.showMessageDialog(iFrame, instruction);
    
        /*#####################################################################
        * GAME INITIALIZATION
        *#####################################################################
        */
    
        //initialize piece button
        iPieces = piecesInitialization();
    
        //adds player 1 pieces into panel
        iRedButton = initializePlayer(iPieces.get(red),iBoard);
    
        //adds player 2 pieces into panel
        iBlueButton = initializePlayer(iPieces.get(blue),iBoard);
    
        //initialize the timer
        iTimer = new Timer(30,new TimerListener());
    
    
        /*#######################################################################
         * AUDIO BACKGROUND
         *#######################################################################
         */
        AudioInputStream lAudioIn = AudioSystem.getAudioInputStream(this.getClass().getResource("chess_music.wav"));
        Clip lClip;
        try {
            lClip = AudioSystem.getClip();
            lClip.open(lAudioIn);
            lClip.start();
            lClip.loop(lClip.LOOP_CONTINUOUSLY);
        } catch (LineUnavailableException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }


    /**
    * main method for Myrmidon
     * @throws IOException
     * @throws UnsupportedAudioFileException
    */
    public static void main(String[] args) throws UnsupportedAudioFileException, IOException {
        new Myrmidon();
    }



    /*#####################################################################
     * ACTION LISTENER CLASS
     * ####################################################################
     */

    class MenuButtonListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {

            JButton temp = (JButton)e.getSource();
            String lAction = temp.getName();

            switch (lAction) {
                case "New Game":
                    newGame();
                    break;
                case "Quit":
                    System.exit(0);
                case "Save Game":
                    try{
    
                        FileOutputStream lFOS;
                        ObjectOutputStream lOOS;
                        for(String lFilename:filenames){
    
                            lFOS = new FileOutputStream(lFilename);
                            lOOS = new ObjectOutputStream(lFOS);
    
                            if(lFilename.equals("Myrmidonrp.txt")){
                                for(int i=0; i<iRedPiece.size(); i++){
                                    ChessPiece lRP= iRedPiece.get(i);
                                         lOOS.writeObject(lRP);
    
                                }
                            }
                            else if(lFilename.equals("Myrmidonbp.txt")){
                                for(int i=0; i<iBluePiece.size(); i++){
                                    ChessPiece lBP= iBluePiece.get(i);
    
                                    lOOS.writeObject(lBP);
    
                                }
                            }
                            else if(lFilename.equals("Myrmidontiles.txt")){
                                for(int i=0; i<iChessTiles.getChessTilesSize(); i++){
                                    ChessTile lT= iChessTiles.getChessTiles().get(i);
                                    lOOS.writeObject(lT);
    
                                }
                            }
                            else if(lFilename.equals("Myrmidoncount.txt")) {
                                int lCounter = iCounter;
                                int lStop = -1;
                                lOOS.writeObject(lCounter);
                                lOOS.writeObject(lStop);
    
                            }
                            else if(lFilename.equals("Myrmidonturn.txt")) {
                                boolean lBlueTurn = iBlueTurn;
                                String lT = String.valueOf(lBlueTurn);
                                lOOS.writeObject(lT);
                            }
                            lOOS.writeObject(null);
                            lOOS.close();
                            lFOS.close();
                        }
    
                    }
                    catch (FileNotFoundException ex) {
                        System.out.println("\n[Error] File not found...");
                    }
                    catch (IOException ex) {
                        System.out.println("\n[Error] Initialization of stream fail...");
                    }
                    break;
    
                case "Load Game":
    
                    try{
                        iChessTiles.clearChessTiles();
                        iRedPiece.clear();
                        iBluePiece.clear();
    
                        for(String lFilename:filenames) {
                            FileInputStream lFIS = new FileInputStream(lFilename);
                            ObjectInputStream lOIS = new ObjectInputStream(lFIS);
                            boolean lContinue = true;
    
                            if(lFilename.equals("Myrmidonbp.txt")){
                                while(lContinue ==true){
                                    ChessPiece lPiece= (ChessPiece)lOIS.readObject();
                                    if(lPiece != null)
                                        iBluePiece.add(lPiece);
                                    else
                                        lContinue=false;
                                }
                            }
                            else if(lFilename.equals("Myrmidonrp.txt")){
                                while(lContinue==true){
                                    ChessPiece lPiece = (ChessPiece)lOIS.readObject();
                                    if(lPiece != null)
                                        iRedPiece.add(lPiece);
                                    else
                                        lContinue=false;
                                }
                            }
                            else if(lFilename.equals("Myrmidontiles.txt")){
                                while(lContinue==true){
                                    ChessTile lTiles= (ChessTile)lOIS.readObject();
                                    if(lTiles != null)
                                        iChessTiles.addChessTile(lTiles);
                                    else
                                        lContinue=false;
                                }
                            }
                            else if(lFilename.equals("Myrmidoncount.txt")) {
                                while(lContinue==true){
                                    int lCount = (int)lOIS.readObject();
                                    if(lCount == -1)
                                        lContinue = false;
                                    else
                                        iCounter = lCount;
                                }
    
                            }
                            else if(lFilename.equals("Myrmidonturn.txt")) {
                                while(lContinue==true){
    
                                    String lTurn= (String)lOIS.readObject();
                                    if(lTurn!=null) {
                                    	
                                        iBlueTurn = Boolean.parseBoolean(lTurn);
    
                                    }else {
                                        lContinue=false;
                                    }
                                }
                            }
    
                            lOIS.close();
                            lFIS.close();
                        }
    
                    }
                    catch(EOFException ex){
                        System.out.println("\nFile has been loaded...");
                    }
                    catch (FileNotFoundException ex) {
                        System.out.println("\n[Error] File not found...");
    
                    }
                    catch (IOException ex) {
                        System.out.println("\n[Error] Initialization of stream fail...");
    
                    }
                    catch (ClassNotFoundException ex) {
                        ex.printStackTrace();
                    }
    
                    loadGame();
                    break;
    

            }

        }

    }


    /**
    * PieceListener - piece action listener
    * @local lTempButton current pressing button
    */
    class PieceListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e){
            JButton lTempButton = (JButton)e.getSource();
            //validate if it is enemy
            if(iPiece != null ) {
            	
	            iEnemyPiece = lTempButton;
	            iFinalPoint = new Point(lTempButton.getX(),lTempButton.getY());
	            iFinalPointValidation = new Point(lTempButton.getX(),lTempButton.getY());
	            iTimer.start();
	            iStartTime = System.currentTimeMillis(); //get start time

            }else {
            	
                iPiece = lTempButton;
                iInitialPoint = new Point(lTempButton.getX(),lTempButton.getY());
                iInitialPointValidation = new Point(lTempButton.getX(),lTempButton.getY());
                

            }
        }
    }

    /**
    * TimerListener - timer action listener
    * @local lRandom - random number to display error message
    */
    class TimerListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            // check the validation for piece movement
            iPieceValidation = getChessPiece(iPiece.getName(),iInitialPointValidation).validateMove(iFinalPointValidation);
             
            if(iPieceValidation && validateMovement() && turn(Character.toString(iPiece.getName().charAt(0))) ) {

                if (iEnable) {
                    disableButton();
                    iEnable = false;
                }

                movePiece();

            }else {
            	
                if(!turn(Character.toString(iPiece.getName().charAt(0)))){
                    char lRandom = Integer.toString((int)System.currentTimeMillis()).charAt(6);
                    JOptionPane.showMessageDialog(iBoard, warning[Integer.parseInt(String.valueOf(lRandom))]);
                }else {
                    JOptionPane.showMessageDialog(iBoard, "INVALID MOVEMENT!!!");
                }
                reset();
                
            }
        }
    }

    /**
    * TileListener class - tiles action listener
    * @local lTempButton current pressing button
    */
    class TileListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e){
            JButton lTempButton = (JButton)e.getSource();
            if(iPiece != null) {

		        iFinalPoint = new Point(lTempButton.getX(),lTempButton.getY());
		        iFinalPointValidation = new Point(lTempButton.getX(),lTempButton.getY());
		
		        iTimer.start();
		        iStartTime = System.currentTimeMillis(); //get start time
            
            }
        }
    }

    
    /*#####################################################################
     * GAME LOGIC METHODS
     * ####################################################################
     */

    /**
     *  The piece movement
     * @local lDuration - duration for piece to reach tile
     * @local lSpeed - speed of movement (unit: pixels per sec)
     * @local lDistanceX - X distance between piece and tile
     * @local lDistanceY - Y distance between piece and tile
     * @local lCurrentX - real time X coordinates of piece
     * @local lCurrentY - real time Y coordinates of piece
     * @local diffX - the different current position and the final position
     * @local diffY - the different current position and the final position
     */
    protected void movePiece() {

        if(iInitialPoint != null && iFinalPoint != null) {

            //Calculate the distance the piece will travel
            int lDistanceX = (int) iInitialPoint.getX() - (int) iFinalPoint.getX();
            int lDistanceY = (int) iInitialPoint.getY() - (int) iFinalPoint.getY();

            double lDuration = (System.currentTimeMillis() - iStartTime)/10;

            //speed of the piece movement
            int lSpeed = 1500;
            //negative horizontal movement
            if(lDistanceX < 0 && lDistanceY == 0 ) {

            	iDistanceSoFarX = -(lSpeed * lDuration / 1000);
                iDistanceSoFarY = 0;

            //negative vertical movement
            }else if(lDistanceY < 0 && lDistanceX == 0){

                iDistanceSoFarX = 0;
                iDistanceSoFarY = -(lSpeed * lDuration / 1000d);

            //positive vertical and negative horizontal movement
            }else if(lDistanceX > 0 && lDistanceY < 0){

                if((lSpeed * lDuration / 1000d) < lDistanceX  )
                iDistanceSoFarX = lSpeed * lDuration / 1000d;
                if(-(lSpeed * lDuration / 1000d) > lDistanceY  )
                iDistanceSoFarY = -(lSpeed * lDuration / 1000d);

            //negative vertical and positive horizontal movement
            }else if(lDistanceX < 0 && lDistanceY > 0){

                if(-(lSpeed * lDuration / 1000d) > lDistanceX  )
                iDistanceSoFarX = -(lSpeed * lDuration / 1000d);
                if((lSpeed * lDuration / 1000d) < lDistanceY  )
                iDistanceSoFarY = lSpeed * lDuration / 1000d;

            //negative vertical and negative horizontal movement
            }else if(lDistanceX < 0 && lDistanceY < 0){

                if(-(lSpeed * lDuration / 1000d) > lDistanceX  )
                iDistanceSoFarX = -(lSpeed * lDuration / 1000d);
                if(-(lSpeed * lDuration / 1000d) > lDistanceY  )
                iDistanceSoFarY = -(lSpeed * lDuration / 1000d);

            //other movement than stated above
            }else {

                iDistanceSoFarX = Math.min(lSpeed * lDuration / 1000d, lDistanceX);
                iDistanceSoFarY = Math.min(lSpeed * lDuration / 1000d, lDistanceY);

            }

            //calculate the current position of the piece
            int lCurrentX = (int) iInitialPoint.getX() - (int)iDistanceSoFarX;
            int lCurrentY = (int) iInitialPoint.getY() - (int)iDistanceSoFarY;

            //this is to move the piece at real time
            iPiece.setLocation(lCurrentX, lCurrentY);

            //calculate the different between current position and the final position of the piece
            int lDiffX = lCurrentX - (int) iFinalPoint.getX();
            int lDiffY = lCurrentY - (int) iFinalPoint.getY();

            /*
             * if the different calculated in the range then the piece is set to the final location
             * and reset the variables
             */
            if(lDiffX >= -5 && lDiffX <= 5 && lDiffY >= -5 && lDiffY <= 5){
   
                //set the piece to the final location
                iPiece.setLocation((int) iFinalPoint.getX(),(int) iFinalPoint.getY());

                getChessPiece(iPiece.getName(),iInitialPoint).setCurrentPosition(iFinalPoint);
                if(iEnemyPiece != null && !Character.toString(iEnemyPiece.getName().charAt(0)).equals(Character.toString(iPiece.getName().charAt(0)))) {

                    if(Character.toString(iEnemyPiece.getName().charAt(0)).equals(red)) {
                        //remove from board ui
                        iBoard.remove(getPieceButton(iRedButton,iEnemyPiece.getLocation(),iEnemyPiece.getName()));
                        if(iEnemyPiece.getName().substring(1).equals("Sun")) {
                            JOptionPane.showMessageDialog(iFrame, "CONGRATULATIONS BLUE!! YOU'RE THE WINNER");
                            iEndGame = true;
                        }
                        //remove from button list
                        removeButtonFromArray(iRedButton,iEnemyPiece.getLocation(),iEnemyPiece.getName());
                        //remove from piece list
                        removePieceFromArrayList(iRedPiece,iEnemyPiece.getLocation(),iEnemyPiece.getName());

                    }else{
                        //remove from board ui
                        iBoard.remove(getPieceButton(iBlueButton,iEnemyPiece.getLocation(),iEnemyPiece.getName()));
                        if(iEnemyPiece.getName().substring(1).equals("Sun")) {
                            JOptionPane.showMessageDialog(iFrame, "CONGRATULATIONS RED!! YOU'RE THE WINNER");
                            iEndGame = true;
                        }
                        //remove from button list
                        removeButtonFromArray(iBlueButton,iEnemyPiece.getLocation(),iEnemyPiece.getName());
                        //remove from piece list
                        removePieceFromArrayList(iBluePiece,iEnemyPiece.getLocation(),iEnemyPiece.getName());
                    }

                }

                    iChessTiles.getChessTileByCoordinate(iInitialPoint).setEmpty(true);
                    iChessTiles.getChessTileByCoordinate(iInitialPoint).setPieceColor(null);
                    iChessTiles.getChessTileByCoordinate(iInitialPoint).setPieceName(null);

                    iChessTiles.getChessTileByCoordinate(iFinalPoint).setEmpty(false);
                    iChessTiles.getChessTileByCoordinate(iFinalPoint).setPieceColor(Character.toString(iPiece.getName().charAt(0)));
                    iChessTiles.getChessTileByCoordinate(iFinalPoint).setPieceName(iPiece.getName().substring(0));

                    iCounter++;

                    //turn logic
                    if (iBlueTurn) {
                        iBlueTurn = false;
                        iRedTurn = true;
                    }else {
                        iBlueTurn = true;
                        iRedTurn= false;
                    }

                    //transform logic
                    if (iCounter == 6) {
                        transform(iRedPiece, iRedButton);
                        transform(iBluePiece, iBlueButton);
                        iCounter = 0;
                    }

                    enableButton();

                    if (iEndGame) {
                        iEndGame = false;
                        newGame();
                    }
                    
                //reset game variable 
                reset();
            }
        }
    }

    /**
     * 
     */
    public void reset() {
        iTimer.stop();
        iEnemyPiece = null;
        iPiece = null;
        iFinalPoint = null;
        iFinalPointValidation = null;
        iInitialPoint = null;
        iInitialPointValidation = null;
        iPieceValidation = false;
        iDistanceSoFarX = 0 ;
        iDistanceSoFarY = 0 ;
        iEnable = true;

    }

    /**
     * 
     * @return
     */
    public boolean validateMovement() {

        ArrayList<Point> lPossibleCoordinates = getChessPiece(iPiece.getName(),iInitialPointValidation).getPossibleTiles(iFinalPointValidation);

        for(Point lTile : lPossibleCoordinates) {
            if(lPossibleCoordinates.indexOf(lTile) == lPossibleCoordinates.size()-1 ) {
                if(iPiece != null && iEnemyPiece != null && !Character.toString(iEnemyPiece.getName().charAt(0)).equals(Character.toString(iPiece.getName().charAt(0)))) {
                    return true;
                }else if(iPiece != null && iEnemyPiece == null && iChessTiles.getChessTileByCoordinate(lTile).isEmpty()) {
                    return true;
                }

            }else{
                if(!iChessTiles.getChessTileByCoordinate(lTile).isEmpty())
                return false;
            }
        }

        return false;
    }

    /**
     * 
     * @param aChessPieces
     * @param aButtons
     */
    public void transform(ArrayList<ChessPiece> aChessPieces, JButton[] aButtons) {

        Stack<ChessPiece> lChessPieceStack = new Stack<ChessPiece>();
        for(ChessPiece lPiece :aChessPieces) {
            lChessPieceStack.push(lPiece);
        }

        Iterator<ChessPiece> lChessPieceIterator = lChessPieceStack.iterator();

        while(lChessPieceIterator.hasNext()) {

            ChessPiece lChessPiece = lChessPieceIterator.next();
            if(!lChessPiece.getName().equals("Sun")) {
            ChessPiece lPiece = lChessPiece.transform(aChessPieces);
            //remove the old button from the board
            JButton lOldButton = getPieceButton(aButtons,lChessPiece.getCurrentPosition(),lChessPiece.getColor()+lChessPiece.getName());
            iBoard.remove(lOldButton);
            //create new button to the board
            JButton lNewButton = createNewButton(lPiece,iBoard);


            //replace button
            replaceButtonFromArray(aButtons,lOldButton,lNewButton);
            }
        }


    }

    /**
     * 
     */
    public void enableButton() {
        iChessBoardFacade.enableButton(iTile);
        iChessBoardFacade.enableButton(iRedButton);
        iChessBoardFacade.enableButton(iBlueButton);
        if(iBlueTurn==true){
            iNotification.setText("It is blue's turn!");
        }
        else{
            iNotification.setText("It is red's turn!");
        }

    }
    
    /**
     * 
     */
    public void disableButton() {
        iChessBoardFacade.disableButton(iTile);
        iChessBoardFacade.disableButton(iRedButton);
        iChessBoardFacade.disableButton(iBlueButton);
    }

    /**
     * 
     * @param aColor
     * @return
     */
    public boolean turn(String aColor) {
        if(aColor.equals(blue)) {
            return iBlueTurn;
        }else {
            return iRedTurn;
        }
    }

    /**
     * This method initialize player by passing player pieces.
     * @param aPiece - ArrayList of the player pieces
     * @param aBoard - Chess board panel
     * @return Piece Buttons
     */
    public JButton[] initializePlayer( ArrayList<ChessPiece> aPiece,JLayeredPane aBoard) {
        JButton lPlayer[] = new JButton[7];
        Border lEmptyBorder = BorderFactory.createEmptyBorder();

        for(int i=0; i< aPiece.size(); i++){
            lPlayer[i] = new JButton();
            lPlayer[i].setLocation(aPiece.get(i).getCurrentPosition());
            lPlayer[i].setFocusPainted( false );
            lPlayer[i].setContentAreaFilled( false );
            lPlayer[i].setIcon(loadImage(aPiece.get(i).getColor()+ aPiece.get(i).getName()+ ".png"));
            lPlayer[i].setSize(100, 100);
            lPlayer[i].setBorder(lEmptyBorder);
            lPlayer[i].setName(aPiece.get(i).getColor()+aPiece.get(i).getName());
            lPlayer[i].addActionListener(new PieceListener());
            ChessTile lChessTile = iChessTiles.getChessTileByCoordinate(aPiece.get(i).getCurrentPosition());
            lChessTile.setEmpty(false);
            lChessTile.setPieceColor(aPiece.get(i).getColor());
            lChessTile.setPieceName(aPiece.get(i).getColor()+ aPiece.get(i).getName());
            aBoard.add(lPlayer[i], 1, -1);
        }
        return lPlayer;
    }

    /**
     * Initialize a new game
     * Set the initial position of both red and blue pieces
     * @return HashMap for the chess piece information
     */
    public HashMap<String,ArrayList<ChessPiece>> piecesInitialization(){

        HashMap<String,ArrayList<ChessPiece>> lChessPieces = new HashMap<String,ArrayList<ChessPiece>>();

        iRedPiece = new ArrayList<ChessPiece>();
        iBluePiece = new ArrayList<ChessPiece>();

        //RED
        ChessPiece lRedPlus1 = new Plus(new Point(0,0),red);
        iRedPiece.add(lRedPlus1);

        ChessPiece lRedPlus2 = new Plus(new Point(600,0),red);
        iRedPiece.add(lRedPlus2);

        ChessPiece lRedTriangle1 = new Triangle(new Point(100,0), red);
        iRedPiece.add(lRedTriangle1);

        ChessPiece lRedTriangle2 = new Triangle(new Point(500,0), red);
        iRedPiece.add(lRedTriangle2);

        ChessPiece lRedChevron1 = new Chevron(new Point(200,0), red);
        iRedPiece.add(lRedChevron1);

        ChessPiece lRedChevron2 = new Chevron(new Point(400,0), red);
        iRedPiece.add(lRedChevron2);

        ChessPiece lRedSun = new Sun(new Point(300,0), red);
        iRedPiece.add(lRedSun);
        lChessPieces.put(red, iRedPiece);


        //BLUE
        ChessPiece lBluePlus1 = new Plus(new Point(0,500),blue);
        iBluePiece.add(lBluePlus1);

        ChessPiece lBluePlus2 = new Plus(new Point(600,500),blue);
        iBluePiece.add(lBluePlus2);

        ChessPiece lBlueTriangle1 = new Triangle(new Point(100,500), blue);
        iBluePiece.add(lBlueTriangle1);

        ChessPiece lBlueTriangle2 = new Triangle(new Point(500,500), blue);
        iBluePiece.add(lBlueTriangle2);

        ChessPiece lBlueChevron1 = new Chevron(new Point(200,500), blue);
        iBluePiece.add(lBlueChevron1);

        ChessPiece lBlueChevron2 = new Chevron(new Point(400,500), blue);
        iBluePiece.add(lBlueChevron2);

        ChessPiece lBlueSun = new Sun(new Point(300,500), blue);
        iBluePiece.add(lBlueSun);

        lChessPieces.put(blue, iBluePiece);

        return lChessPieces;
    }

    /*#####################################################################
     * HELPER METHODS
     * ####################################################################
     */

    /**
     * 
     * @param aButtons
     */
    public void removePieceButtonFromTheBoard(JButton[] aButtons) {
        for(JButton aButton : aButtons) {
            if(aButton != null) {
                iBoard.remove(aButton);
                aButton = null;
            }
        }
    }

    /**
     * 
     * @param aPiece
     * @param aBoard
     * @return
     */
    public JButton createNewButton(ChessPiece aPiece, JLayeredPane aBoard) {
        Border lEmptyBorder = BorderFactory.createEmptyBorder();

        JButton lButton = new JButton();
        lButton.setLocation(aPiece.getCurrentPosition());
        lButton.setFocusPainted( false );
        lButton.setContentAreaFilled( false );
        lButton.setIcon(loadImage(aPiece.getColor()+ aPiece.getName()+ ".png"));
        lButton.setSize(100, 100);
        lButton.setBorder(lEmptyBorder);
        lButton.setName(aPiece.getColor()+aPiece.getName());
        lButton.addActionListener(new PieceListener());
        ChessTile lChessTiles = iChessTiles.getChessTileByCoordinate(aPiece.getCurrentPosition());
        lChessTiles.setEmpty(false);
        lChessTiles.setPieceColor(aPiece.getColor());
        lChessTiles.setPieceName(aPiece.getColor()+aPiece.getName());
        aBoard.add(lButton, 1, -1);

        return lButton;
    }


    /**
     * 
     * @param aChessPieces
     * @param aPoint
     * @param aName
     */
    public void removePieceFromArrayList(ArrayList<ChessPiece> aChessPieces, Point aPoint, String aName) {

        for (ChessPiece lPiece : aChessPieces) {
            if((lPiece.getColor()+lPiece.getName()).equals(aName) && lPiece.getCurrentPosition().equals(aPoint)) {
                aChessPieces.remove(lPiece);
                break;
            }
        }

    }

    /**
     * 
     * @param aButtons
     * @param aPoint
     * @param aName
     */
    public void removeButtonFromArray(JButton[] aButtons, Point aPoint, String aName) {
        for (int i = 0 ; i<aButtons.length; i++) {
            if(aButtons[i] != null)
            if(aButtons[i].getName().equals(aName) && aButtons[i].getLocation().equals(aPoint)) {
				aButtons[i] = null;
				break;
			}
		}
	}

    /**
     * 
     * @param aButtons
     * @param aOldButton
     * @param aNewButton
     */
	public void replaceButtonFromArray(JButton[] aButtons, JButton aOldButton, JButton aNewButton) {
		for (int i = 0 ; i<aButtons.length; i++) {
			if(aButtons[i] != null)
			if(aButtons[i].getName().equals(aOldButton.getName()) && aButtons[i].getLocation().equals(aOldButton.getLocation())) {
				aButtons[i] = aNewButton;
				break;
			}
		}
	}

	/**
	 * 
	 * @param aName
	 * @param aInitialCoordinate
	 * @return
	 */
	public ChessPiece getChessPiece(String aName, Point aInitialCoordinate) {
		ArrayList<ChessPiece> lChessPieces = new ArrayList<ChessPiece>();
		lChessPieces = iPieces.get(Character.toString(aName.charAt(0)));
		ChessPiece lChessPiece = null;
		for (ChessPiece lPiece : lChessPieces) {
			if((lPiece.getColor()+lPiece.getName()).equals(aName) && lPiece.getCurrentPosition().equals(aInitialCoordinate)) {
				lChessPiece = lPiece;
				break;
			}
		}

		return lChessPiece;
	}

	/**
	 * 
	 * @param aTeam
	 * @param aPoint
	 * @param aName
	 * @return
	 */
	public JButton getPieceButton(JButton[] aTeam, Point aPoint, String aName) {
		JButton lPiece = new JButton();

		for(JButton aButton : aTeam) {
			if(aButton != null)
			if(aButton.getName().equals(aName) && aButton.getLocation().equals(aPoint)) {
				lPiece = aButton;
				break;
			}
		}

		return lPiece;
	}

	/**
	 *
	 * @param aPath
	 * @return
	 */
	private ImageIcon loadImage(String aPath){
        Image lImage = new ImageIcon(this.getClass().getResource(aPath)).getImage();
        Image lScaledImage = lImage.getScaledInstance(100, 100,  java.awt.Image.SCALE_SMOOTH);
        return new ImageIcon(lScaledImage);
    }

	/*#####################################################################
	 * MENU BUTTON RELATED METHODS
	 * ####################################################################
	 */

	/**
	 * This method initialize the new game
	 * It will be activated when the winner is announced from previous game
	 * or when the button is clicked.
	 */
	public void newGame(){
		
		removePieceButtonFromTheBoard(iRedButton);
		removePieceButtonFromTheBoard(iBlueButton);
		removePieceButtonFromTheBoard(iTile);
		iNotification.setText("<html>New Game<br/>Blue's turn</html>");
		iCounter = 0;
		iChessTiles = new ChessTile();
		iChessTiles.setChessTiles(iChessBoardFacade.setChessTiles(iTile, iBoard,new TileListener()));
		//initialize piece button
		iPieces = new HashMap<String,ArrayList<ChessPiece>>();
		iPieces = piecesInitialization();
		//iGameStart = true;
		//adds player 1 pieces into panel
		iRedButton = initializePlayer(iPieces.get(red),iBoard);

		//adds player 2 pieces into panel
		iBlueButton = initializePlayer(iPieces.get(blue),iBoard);
		reset();
		iBlueTurn = true;
		iRedTurn = false;

	}

	/**
	 * This method load the saved game
	 */
	public void loadGame() {
		
		removePieceButtonFromTheBoard(iRedButton);
		removePieceButtonFromTheBoard(iBlueButton);
		removePieceButtonFromTheBoard(iTile);
		
		if (!iBlueTurn) {
			
			iBlueTurn = false;
			iRedTurn = true;
			
		}else {
			
			iBlueTurn = true;
			iRedTurn= false;
			
		}
		
		if(iBlueTurn==true & iChessTiles.getChessTiles().size() != 0){
			
			iNotification.setText("<html>Succesfully Loaded<br/>It is blue's turn!</html>");
			
		}else if(iChessTiles.getChessTiles().size() == 0){
			
			iNotification.setText("<html>You don't have<br/>any saved game</html>");
			
		}else{
			
			iNotification.setText("<html>Succesfully Loaded<br/>It is red's turn!</html>");	
			
		}

		iChessTiles = new ChessTile();
		iChessTiles.setChessTiles(iChessBoardFacade.setChessTiles(iTile, iBoard,new TileListener()));

		iRedButton = initializePlayer(iRedPiece,iBoard);
		iBlueButton = initializePlayer(iBluePiece,iBoard);


	}

}
