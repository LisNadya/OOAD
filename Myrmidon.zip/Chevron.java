 

import java.awt.Point;
import java.util.ArrayList;

/*
 * 
 */
public class Chevron extends ChessPiece
{
	//iName - name of Chevron is always chevron
	private static final String iName = "Chevron";
	
    /**
     * ChessPiece - ChessPiece constructor
     * @param aFinalPoint - arguement for final point
     * @param aColor - arguement for color
     */
    public Chevron(Point aFinalPoint, String aColor)
    {
        super(aFinalPoint, aColor);
    }
    
    /**
     * validateMove - Function that determines if pathway is valid
     * @param aInitialPoint - arguement for initial point
     * @param aFinalPoint - arguement for final point
     * @return lValid - local variable for valid check
     */
    public boolean validateMove(Point aFinalPoint){
        boolean lValid = false;
        /*
         * Checks if chosen tile is valid
         */
        if(Math.abs(super.getCurrentPosition().getX()-aFinalPoint.getX())==200&&Math.abs(super.getCurrentPosition().getY()-aFinalPoint.getY())==100)
            lValid = true;
        else if(Math.abs(super.getCurrentPosition().getX()-aFinalPoint.getX())==100&&Math.abs(super.getCurrentPosition().getY()-aFinalPoint.getY())==200)
            lValid = true;
            
        return lValid;
    }
    
    /**
     * transform - Function that indicates next transformation of Piece
     */
    public ChessPiece transform(ArrayList<ChessPiece> aChessPiece){
		ChessPiece chessPiece = null;
		for(ChessPiece lChessPiece : aChessPiece ) {
			if(getName().equals(lChessPiece.getName()) && super.getCurrentPosition().equals(lChessPiece.getCurrentPosition())) {
				chessPiece = new Plus(super.getCurrentPosition(),super.getColor());
				aChessPiece.remove(lChessPiece);
				aChessPiece.add(chessPiece);
				break;
			}
		}
		
		
		
		return chessPiece;
    }

	@Override
	public String getName() {
		return iName;
	}

	@Override
	public ArrayList<Point> getPossibleTiles(Point aFinalPoint) {
		ArrayList<Point> iCoordinates = new ArrayList<Point>();
    	
		if(validateMove(aFinalPoint))	
    	iCoordinates.add(aFinalPoint);
    	
    	return iCoordinates;
	}
}
