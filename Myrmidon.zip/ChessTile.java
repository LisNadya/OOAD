 

import java.awt.Point;
import java.io.Serializable;
import java.util.ArrayList;

public class ChessTile implements Serializable{
	
	private Point location;
	private boolean isEmpty = true;
	private String  pieceName;
	private String pieceColor;
	private ArrayList<ChessTile> chessTiles = new ArrayList<ChessTile>(); //SAVE

	
	/**
	 * @return the pieceName
	 */
	public String getPieceName() {
		return pieceName;
	}
	/**
	 * @param pieceName the pieceName to set
	 */
	public void setPieceName(String pieceName) {
		this.pieceName = pieceName;
	}
	/**
	 * @return the location
	 */
	public Point getLocation() {
		return location;
	}
	/**
	 * @param location the location to set
	 */
	public void setLocation(Point location) {
		this.location = location;
	}
	/**
	 * @return the isEmpty
	 */
	public boolean isEmpty() {
		return isEmpty;
	}
	/**
	 * @param isEmpty the isEmpty to set
	 */
	public void setEmpty(boolean isEmpty) {
		this.isEmpty = isEmpty;
	}

	/**
	 * @return the pieceColor
	 */
	public String getPieceColor() {
		return pieceColor;
	}
	/**
	 * @param pieceColor the pieceColor to set
	 */
	public void setPieceColor(String pieceColor) {
		this.pieceColor = pieceColor;
	}
	/**
	 * This method is to get chess Tiles
	 * @return the iChessTiles
	 */
	public ArrayList<ChessTile> getChessTiles() {
		return chessTiles;
	}

	/**
	 * This method adding the tile to an array
	 * @param aTile
	 */
	public void addChessTile(ChessTile aTile) {
		chessTiles.add(aTile);
	}
	
	/**
	 * This method is to clear the chessTiles array
	 */
	public void clearChessTiles(){
		chessTiles.clear();
	}
	
	/**
	 * This method is to get the chessTiles array size
	 */
	public int getChessTilesSize(){
		return chessTiles.size();
	}
	
	/**
	 * This method is setting the chessTiles
	 * @param iChessTiles
	 */
	public void setChessTiles(ArrayList<ChessTile> iChessTiles) {
		this.chessTiles = iChessTiles;
	}
	
	public ChessTile getChessTileByCoordinate(Point aChessTile) {
		ChessTile lTile = new ChessTile();
		for(ChessTile lChessTile : chessTiles) {
			if(lChessTile.getLocation().getX() == aChessTile.getX() && lChessTile.getLocation().getY() == aChessTile.getY()) {
				lTile = lChessTile;
				break;
			}
		}
		
		return lTile; 
	}

}