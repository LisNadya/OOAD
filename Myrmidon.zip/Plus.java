 
import java.awt.Point;
import java.util.ArrayList;

/**
 * Write a description of class Plus here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Plus extends ChessPiece
{

	//iName - name of Plus is always plus
	private static final String iName = "Plus";
	
	public Plus(Point aFinalPoint, String aColor) {
		super(aFinalPoint, aColor);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean validateMove(Point aFinalPoint) {
		 boolean lValid = false;
	        
		 int diffx = (int)super.getCurrentPosition().getX() - (int)aFinalPoint.getX();
		 int diffy = (int)super.getCurrentPosition().getY() - (int)aFinalPoint.getY();
	       /*
	       * Checks if chosen tile is valid
	       */
	       if ((super.getCurrentPosition().getX() == aFinalPoint.getX() && Math.abs(diffy)<=200) || (super.getCurrentPosition().getY() == aFinalPoint.getY() && Math.abs(diffx)<=200) ){
	            if (super.getCurrentPosition().getX() == aFinalPoint.getX() && super.getCurrentPosition().getY() == aFinalPoint.getY()){
	                lValid = false;
	            }
	            lValid = true;
	        }
	       
	       return lValid;
	}

	@Override
	public ChessPiece transform(ArrayList<ChessPiece> aChessPiece) {
		ChessPiece chessPiece = null;
		for(ChessPiece lChessPiece : aChessPiece ) {
			
			if(getName().equals(lChessPiece.getName()) && super.getCurrentPosition().equals(lChessPiece.getCurrentPosition())) {
				
				chessPiece = new Triangle(super.getCurrentPosition(),super.getColor());
				aChessPiece.remove(lChessPiece);
				aChessPiece.add(chessPiece);
				break;
				
			}
		}
		
		
		
		return chessPiece;
	}

	@Override
	public String getName() {
		return iName;
	}

	@Override
	public ArrayList<Point> getPossibleTiles(Point aFinalPoint) {
		ArrayList<Point> iCoordinates = new ArrayList<Point>();
    	
		if(validateMove(aFinalPoint))		
			if(super.getCurrentPosition().getX()< aFinalPoint.getX()) {
				
				for(int i = 1; i<Math.abs((super.getCurrentPosition().getX()-aFinalPoint.getX())/100) + 1 ;i++ ) {
					iCoordinates.add(new Point((int) super.getCurrentPosition().getX() + (i*100), (int) super.getCurrentPosition().getY()));
				}
				
			}else if(super.getCurrentPosition().getX()> aFinalPoint.getX()){
				
				for(int i = 1; i<Math.abs((super.getCurrentPosition().getX()-aFinalPoint.getX())/100) + 1 ;i++ ) {
					iCoordinates.add(new Point((int) super.getCurrentPosition().getX() - (i*100) , (int) super.getCurrentPosition().getY() ));
				}
				
			}else if(super.getCurrentPosition().getY()< aFinalPoint.getY()) {
				
				for(int i = 1; i<Math.abs((super.getCurrentPosition().getY()-aFinalPoint.getY())/100) + 1 ;i++ ) {
					iCoordinates.add(new Point((int) super.getCurrentPosition().getX(), (int) super.getCurrentPosition().getY()+ (i*100)));
				}
				
			}else {	
				
				for(int i = 1; i<Math.abs((super.getCurrentPosition().getY()-aFinalPoint.getY())/100) + 1 ;i++ ) {
					iCoordinates.add(new Point((int) super.getCurrentPosition().getX(), (int) super.getCurrentPosition().getY() - (i*100)));
				}
			}
    	
    	return iCoordinates;
	}

}
