 
import java.awt.Point;
import java.util.ArrayList;

/**
 * Write a description of class Triangle here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Triangle extends ChessPiece
{

	//iName - name of Triangle is always triangle
	private static final String iName = "Triangle";
		
	public Triangle(Point aFinalPoint, String aColor) {
		super(aFinalPoint, aColor);
	}

	@Override
	public boolean validateMove(Point aFinalPoint) {
		
		int diffx = super.getCurrentPosition().x - aFinalPoint.x;
		int diffy = super.getCurrentPosition().y - aFinalPoint.y;
		if(Math.abs(diffx) == Math.abs(diffy) && Math.abs(diffx) <=200 && Math.abs(diffy) <=200 && diffy != 0 && diffx!= 0) {
			return true;
		}else {
			return false;
		}
	}

	@Override
	public ChessPiece transform(ArrayList<ChessPiece> aChessPiece) {
		ChessPiece chessPiece = null;
		for(ChessPiece lChessPiece : aChessPiece ) {
			if(getName().equals(lChessPiece.getName()) && super.getCurrentPosition().equals(lChessPiece.getCurrentPosition())) {
				chessPiece = new Chevron(super.getCurrentPosition(),super.getColor());
				aChessPiece.remove(lChessPiece);
				aChessPiece.add(chessPiece);
				break;
			}
		}
		
		
		
		return chessPiece;
	}

	@Override
	public String getName() {
		return iName;
	}

	@Override
	public ArrayList<Point> getPossibleTiles(Point aFinalPoint) {
		ArrayList<Point> iCoordinates = new ArrayList<Point>();
		
		int diffx = super.getCurrentPosition().x - aFinalPoint.x;
		int diffy = super.getCurrentPosition().y - aFinalPoint.y;
		
		if(validateMove(aFinalPoint))
		if( diffx < 0 && diffy > 0) {	
			
			for(int i = 1; i<Math.abs((diffx)/100) + 1 ;i++ ) {
				iCoordinates.add(new Point((int) super.getCurrentPosition().getX() + (i*100), (int) super.getCurrentPosition().getY() - (i*100)));
			}
			
		}else if (diffx < 0 && diffy < 0) {
			
			for(int i = 1; i<Math.abs((diffx)/100) + 1 ;i++ ) {
				iCoordinates.add(new Point((int) super.getCurrentPosition().getX() + (i*100), (int) super.getCurrentPosition().getY() + (i*100)));
			}
			
		}else if(diffx > 0 && diffy < 0) {
			
			for(int i = 1; i<Math.abs((diffx)/100) + 1 ;i++ ) {
				iCoordinates.add(new Point((int) super.getCurrentPosition().getX() - (i*100), (int) super.getCurrentPosition().getY() + (i*100)));
			}
			
		}else if(diffx > 0 && diffy > 0) {
			
			for(int i = 1; i<Math.abs((diffx)/100) + 1 ;i++ ) {
				iCoordinates.add(new Point((int) super.getCurrentPosition().getX() - (i*100), (int) super.getCurrentPosition().getY() - (i*100)));
			}
		}
		
		return iCoordinates;
	}

}
