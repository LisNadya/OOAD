 

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

public class ChessBoardFacade {
	
	private CoordinateAdapter iCoordinateAdapter = new CoordinateAdapter();
	
	/**
	 * 
	 * @param aMenu
	 * @param aButtons
	 * @param aActionListener
	 * @param aNotice
	 * @return
	 */
	public JPanel setMenu(String[] aMenu, JButton[] aButtons ,ActionListener aActionListener, JPanel aNotice) {
		
		JPanel lMenuBorder = new JPanel(new GridLayout(3,0)); 
		
		JPanel lMenuNav = new JPanel(new GridLayout(2,2));
		lMenuBorder.setBorder(new EmptyBorder(10, 10, 10, 10));
		lMenuBorder.setPreferredSize(new Dimension(300,1000));
		lMenuBorder.setBackground(Color.BLACK);
		
		JButton lMenuTitle = new JButton();
		lMenuTitle.setIcon(loadImage("Myrmidon.png"));
		lMenuTitle.setBorder(BorderFactory.createEmptyBorder());
		lMenuTitle.setContentAreaFilled(false);
		lMenuTitle.setEnabled(false);
		lMenuTitle.setDisabledIcon(loadImage("Myrmidon.png"));
		lMenuBorder.add(lMenuTitle);
		lMenuBorder.add(aNotice);
		
		for(int i=0; i<4; i++){
			aButtons[i]=new JButton(aMenu[i]); 
			aButtons[i].setName(aMenu[i]); 
			aButtons[i].setBackground(Color.cyan);
			aButtons[i].setForeground(Color.BLACK);
			aButtons[i].addActionListener(aActionListener);
			lMenuNav.add(aButtons[i]);
		}
		
		lMenuBorder.add(lMenuNav);
		return lMenuBorder;
	}
	
	/**
	 * 
	 * @param aPath
	 * @return
	 */
	private ImageIcon loadImage(String aPath){
        Image lImage = new ImageIcon(this.getClass().getResource(aPath)).getImage();
        Image lScaledImage = lImage.getScaledInstance(250, 150,  java.awt.Image.SCALE_SMOOTH);
        return new ImageIcon(lScaledImage);
    }
	
	public JPanel setRowCoordinates(String[] aRow) {
		
		JPanel lRowBorder = new JPanel(new BorderLayout()); 
		lRowBorder.setBorder(new EmptyBorder(10, 10, 10, 10));
		lRowBorder.setLayout(new GridLayout(6,1));
		lRowBorder.setBackground(Color.BLACK);
		
		for(int i=5; i>=0; i--){ 
			JLabel lRow = new JLabel(aRow[i]);
			lRow.setBackground(Color.BLACK);
			lRow.setForeground(Color.WHITE);
			lRowBorder.add(lRow,BorderLayout.WEST);
		}
		
		return lRowBorder;
	}
	
	/**
	 * 
	 * @param aColumn
	 * @return
	 */
	public JPanel setColumnCoordinates(String[] aColumn) {
		
		JPanel lColumnBorder = new JPanel(); 
		lColumnBorder.setBorder(new EmptyBorder(10, 30, 10, 10)); 
		lColumnBorder.setLayout(new GridLayout(1,7)); 
		lColumnBorder.setBackground(Color.BLACK);
		
		for(int i=0; i<7; i++){
			JLabel lCol = new JLabel(aColumn[i], SwingConstants.CENTER);
			lCol.setBackground(Color.BLACK);
			lCol.setForeground(Color.WHITE);
			lColumnBorder.add(lCol);
		}
		
		return lColumnBorder;
	}
	
	/**
	 * 
	 * @param aTileButtons
	 * @param aBoard
	 * @param aTileListener
	 * @return
	 */
	public ArrayList<ChessTile> setChessTiles(JButton[] aTileButtons, JLayeredPane aBoard, ActionListener aTileListener ) {
		ArrayList<ChessTile> lChessTiles = new ArrayList<ChessTile>();
		
		int lCount = 0; 
		for(int j=0; j<6; j++){ 
			for(int i=0; i<7; i++){
				aTileButtons[lCount] = new JButton();
				if(i%2!=0&&j%2==0||i%2==0&&j%2!=0)
					aTileButtons[lCount].setBackground(Color.BLACK);
				else
					aTileButtons[lCount].setBackground(Color.PINK);
				aTileButtons[lCount].setLocation(i * 100, j * 100);
				aTileButtons[lCount].setSize(100, 100);
				aTileButtons[lCount].setName(Integer.toString(i) + Integer.toString(j));
				aTileButtons[lCount].addActionListener(aTileListener);
				aBoard.add(aTileButtons[lCount], 0, -1); 
				ChessTile lChessTile = new ChessTile();
				lChessTile.setEmpty(true);
				lChessTile.setLocation(iCoordinateAdapter.convertNameToCoordinate(new Point(i,j)));
				lChessTile.setPieceName(null);
				lChessTiles.add(lChessTile);
				lCount++;
			}
		}
		
		return lChessTiles;
	}
	
	/**
	 * 
	 * @param aButtons
	 */
	public void disableButton(JButton[] aButtons) {
		for(JButton lButton : aButtons) {
			if(lButton!= null) {
				lButton.setEnabled(false);
			}
				
		}
	}
	
	/**
	 * 
	 * @param aButtons
	 */
	public void enableButton(JButton[] aButtons) {
		for(JButton lButton : aButtons) {
			if(lButton!= null) {
				lButton.setEnabled(true);
			}
				
		}
	}
	

	
	
}
