 

import java.awt.Point;

public class CoordinateAdapter {
	
	/**
	 * 
	 * @param aPoint
	 * @return
	 */
	public Point convertNameToCoordinate(Point aPoint) {
		Point lPoint = new Point((int) aPoint.getX()*100, (int) aPoint.getY()*100);
		return lPoint;
	}
	
	public Point convertCoordinateToName(Point aPoint) {
		Point lPoint = new Point((int) aPoint.getX()/100, (int) aPoint.getY()/100);
		return lPoint;
	}

}
